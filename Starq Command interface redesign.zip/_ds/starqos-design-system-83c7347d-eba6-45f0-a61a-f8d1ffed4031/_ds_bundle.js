/* @ds-bundle: {"format":3,"namespace":"StarqOSDesignSystem_83c734","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"HudLabel","sourcePath":"components/core/HudLabel.jsx"},{"name":"Card","sourcePath":"components/data/Card.jsx"},{"name":"MetricStat","sourcePath":"components/data/MetricStat.jsx"},{"name":"ProgressBar","sourcePath":"components/data/ProgressBar.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"NexusHeader","sourcePath":"components/navigation/NexusHeader.jsx"},{"name":"TabBar","sourcePath":"components/navigation/TabBar.jsx"},{"name":"RzBadge","sourcePath":"components/reimagined/RzBadge.jsx"},{"name":"RzButton","sourcePath":"components/reimagined/RzButton.jsx"},{"name":"RzNeonMark","sourcePath":"components/reimagined/RzNeonMark.jsx"},{"name":"RzPanel","sourcePath":"components/reimagined/RzPanel.jsx"},{"name":"RzPanelRow","sourcePath":"components/reimagined/RzPanel.jsx"},{"name":"RzProgress","sourcePath":"components/reimagined/RzProgress.jsx"},{"name":"RzStat","sourcePath":"components/reimagined/RzStat.jsx"},{"name":"RzCell","sourcePath":"components/reimagined/RzStat.jsx"},{"name":"RzTabBar","sourcePath":"components/reimagined/RzTabBar.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"819cd11a262f","components/core/Button.jsx":"bbf634757013","components/core/HudLabel.jsx":"f5035ca438e6","components/data/Card.jsx":"13eb8f69797d","components/data/MetricStat.jsx":"95a2a9f47788","components/data/ProgressBar.jsx":"a7c113166730","components/forms/Input.jsx":"83ee8194177e","components/forms/Switch.jsx":"b0e3127ce147","components/navigation/NexusHeader.jsx":"104969c021b4","components/navigation/TabBar.jsx":"8116dcac542b","components/reimagined/RzBadge.jsx":"d91c480caa5f","components/reimagined/RzButton.jsx":"a85ceec346eb","components/reimagined/RzNeonMark.jsx":"dc7c23ce78ca","components/reimagined/RzPanel.jsx":"90a861731747","components/reimagined/RzProgress.jsx":"ecb599ac6254","components/reimagined/RzStat.jsx":"fc946f047bcb","components/reimagined/RzTabBar.jsx":"6bac5540560f","ui_kits/starq-nexus-mobile/HomeScreen.jsx":"077903fb9b72","ui_kits/starq-nexus-mobile/LibraryScreen.jsx":"79aaa0f4b47c","ui_kits/starq-nexus-mobile/ProjectsScreen.jsx":"eaef00aabb6c","ui_kits/starq-nexus-mobile/SettingsScreen.jsx":"1cd98035123c"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.StarqOSDesignSystem_83c734 = window.StarqOSDesignSystem_83c734 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Badge — a small status / category pill. Tinted fill + hairline border in its
 * tone, optional leading dot. Uppercase, tracked.
 */
const TONES = {
  clay: {
    c: 'var(--clay-dark)',
    fill: 'var(--clay-12)',
    border: 'var(--clay-40)'
  },
  danger: {
    c: 'var(--danger)',
    fill: 'var(--danger-tint)',
    border: 'var(--danger)'
  },
  warning: {
    c: 'var(--warning)',
    fill: 'var(--warning-tint)',
    border: 'var(--warning)'
  },
  success: {
    c: 'var(--success)',
    fill: 'var(--success-tint)',
    border: 'var(--success)'
  },
  muted: {
    c: 'var(--muted)',
    fill: 'var(--vellum)',
    border: 'var(--line)'
  }
};
function Badge({
  tone = 'clay',
  dot = false,
  children,
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.clay;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '5px',
      padding: '3px 8px',
      borderRadius: 'var(--radius-pill)',
      border: `1px solid ${t.border}`,
      background: t.fill,
      color: t.c,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-2xs)',
      fontWeight: 700,
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      lineHeight: 1.4,
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 5,
      height: 5,
      borderRadius: 'var(--radius-pill)',
      background: t.c
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — the primary action control.
 * Warm, low-radius, hairline-bordered. Four variants, three sizes.
 */
const SIZES = {
  sm: {
    padding: '6px 14px',
    fontSize: 'var(--text-xs)'
  },
  md: {
    padding: '10px 20px',
    fontSize: 'var(--text-sm)'
  },
  lg: {
    padding: '13px 28px',
    fontSize: 'var(--text-md)'
  }
};
const VARIANTS = {
  primary: {
    background: 'var(--clay)',
    color: 'var(--paper-soft)',
    borderColor: 'var(--clay)'
  },
  secondary: {
    background: 'var(--paper-soft)',
    color: 'var(--ink)',
    borderColor: 'var(--line)'
  },
  ghost: {
    background: 'var(--clay-08)',
    color: 'var(--clay-dark)',
    borderColor: 'var(--clay-40)'
  },
  danger: {
    background: 'var(--danger-tint)',
    color: 'var(--danger)',
    borderColor: 'var(--danger)'
  }
};
function Button({
  variant = 'primary',
  size = 'md',
  hud = false,
  full = false,
  disabled = false,
  onClick,
  children,
  style,
  ...rest
}) {
  const v = VARIANTS[variant] || VARIANTS.primary;
  const s = SIZES[size] || SIZES.md;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 'var(--space-sm)',
    fontFamily: 'var(--font-sans)',
    fontWeight: hud ? 700 : 600,
    letterSpacing: hud ? 'var(--tracking-label)' : 'var(--tracking-normal)',
    textTransform: hud ? 'uppercase' : 'none',
    lineHeight: 1,
    border: '1px solid',
    borderRadius: 'var(--radius-xs)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.45 : 1,
    width: full ? '100%' : undefined,
    transition: 'filter var(--dur-fast) var(--ease-standard), transform var(--dur-fast) var(--ease-standard)',
    ...s,
    ...v,
    ...style
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    onClick: onClick,
    style: base,
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = 'scale(0.98)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = 'scale(1)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
      e.currentTarget.style.filter = 'none';
    },
    onMouseEnter: e => {
      if (!disabled) e.currentTarget.style.filter = 'brightness(0.96)';
    }
  }, rest), hud && typeof children === 'string' ? children.toUpperCase() : children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/HudLabel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * HudLabel — the product's signature telemetry label. Uppercase, letter-tracked.
 * Optional leading pip (live dot) and optional [ bracket ] framing for section
 * headers. The system's "voice".
 */
const TONES = {
  muted: 'var(--muted)',
  mutedDark: 'var(--muted-dark)',
  ink: 'var(--ink)',
  onDark: 'var(--paper-soft)',
  vellum: 'var(--vellum)',
  clay: 'var(--clay)',
  clayDark: 'var(--clay-dark)',
  success: 'var(--success)',
  danger: 'var(--danger)'
};
const SIZES = {
  xs: 'var(--text-2xs)',
  sm: 'var(--text-xs)',
  md: 'var(--text-sm)'
};
function HudLabel({
  tone = 'mutedDark',
  size = 'sm',
  pip = false,
  bracket = false,
  children,
  style,
  ...rest
}) {
  const color = TONES[tone] || tone;
  const text = bracket ? `[ ${children} ]` : children;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '7px',
      fontFamily: 'var(--font-sans)',
      fontSize: SIZES[size] || SIZES.sm,
      fontWeight: 700,
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color,
      lineHeight: 1.3,
      ...style
    }
  }, rest), pip && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 'var(--radius-pill)',
      background: color,
      flex: 'none'
    }
  }), text);
}
Object.assign(__ds_scope, { HudLabel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/HudLabel.jsx", error: String((e && e.message) || e) }); }

// components/data/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — the standard content surface. Paper by default (use `dark` for the
 * charcoal shell). Optional HUD header label, optional edge accent stripe in a
 * status/domain hue.
 */
function Card({
  label,
  accent,
  dark = false,
  pip = false,
  children,
  style,
  bodyStyle,
  ...rest
}) {
  const surface = dark ? {
    background: 'var(--charcoal-soft)',
    borderColor: 'var(--charcoal-line)',
    color: 'var(--paper-soft)'
  } : {
    background: 'var(--paper)',
    borderColor: 'var(--line)',
    color: 'var(--ink)'
  };
  const headColor = dark ? 'var(--muted-dark)' : 'var(--muted)';
  const headBorder = dark ? 'var(--charcoal-divider)' : 'var(--line)';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: 'relative',
      border: '1px solid',
      borderRadius: 'var(--radius-sm)',
      overflow: 'hidden',
      boxShadow: dark ? 'none' : 'var(--shadow-card)',
      ...surface,
      ...style
    }
  }, rest), accent && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      bottom: 0,
      width: 3,
      background: accent
    }
  }), label && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-sm)',
      padding: '10px 14px',
      borderBottom: `1px solid ${headBorder}`
    }
  }, pip && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--clay)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-xs)',
      fontWeight: 700,
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color: pip ? 'var(--clay)' : headColor
    }
  }, label)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-md)',
      ...bodyStyle
    }
  }, children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Card.jsx", error: String((e && e.message) || e) }); }

// components/data/MetricStat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * MetricStat — a big bold numeral over a small uppercase label. The product's
 * way of giving counts, percentages and clocks first-class weight.
 */
const SIZES = {
  sm: 'var(--text-xl)',
  md: 'var(--text-2xl)',
  lg: 'var(--text-display)'
};
function MetricStat({
  value,
  label,
  tone,
  size = 'md',
  align = 'start',
  dark = false,
  style,
  ...rest
}) {
  const valueColor = tone || (dark ? 'var(--paper-soft)' : 'var(--ink)');
  const labelColor = dark ? 'var(--muted-dark)' : 'var(--muted)';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-xs)',
      alignItems: align === 'center' ? 'center' : 'flex-start',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 700,
      lineHeight: 1,
      fontSize: SIZES[size] || SIZES.md,
      color: valueColor,
      fontVariantNumeric: 'tabular-nums',
      letterSpacing: '0.5px'
    }
  }, value), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-2xs)',
      fontWeight: 700,
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color: labelColor
    }
  }, label));
}
Object.assign(__ds_scope, { MetricStat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/MetricStat.jsx", error: String((e && e.message) || e) }); }

// components/data/ProgressBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ProgressBar — a thin sprint/readiness track. Clay fill by default; pass a tone
 * to color it. No glow — a flat warm fill.
 */
function ProgressBar({
  value = 0,
  tone = 'var(--clay)',
  height = 6,
  dark = false,
  style,
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, value));
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "progressbar",
    "aria-valuenow": pct,
    "aria-valuemin": 0,
    "aria-valuemax": 100,
    style: {
      width: '100%',
      height,
      borderRadius: 'var(--radius-pill)',
      background: dark ? 'var(--charcoal-2)' : 'var(--vellum)',
      overflow: 'hidden',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      width: `${pct}%`,
      background: tone,
      borderRadius: 'var(--radius-pill)',
      transition: 'width var(--dur-base) var(--ease-standard)'
    }
  }));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Input — a labelled text field on a paper-soft surface. Hairline border, clay
 * focus ring (no glow). Optional uppercase HUD label and helper text.
 */
function Input({
  label,
  helper,
  dark = false,
  style,
  inputStyle,
  id,
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  const fieldId = id || (label ? `in-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);
  const surface = dark ? {
    background: 'var(--charcoal-2)',
    color: 'var(--paper-soft)'
  } : {
    background: 'var(--paper-soft)',
    color: 'var(--ink)'
  };
  const restBorder = dark ? 'var(--charcoal-line)' : 'var(--line)';
  const labelColor = dark ? 'var(--muted-dark)' : 'var(--muted)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-xs)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-2xs)',
      fontWeight: 700,
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color: labelColor
    }
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    onFocus: e => {
      setFocused(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocused(false);
      rest.onBlur && rest.onBlur(e);
    },
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      padding: '9px 12px',
      border: `1px solid ${focused ? 'var(--clay)' : restBorder}`,
      borderRadius: 'var(--radius-xs)',
      outline: 'none',
      boxShadow: focused ? 'var(--focus-ring)' : 'none',
      transition: 'border-color var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)',
      ...surface,
      ...inputStyle
    }
  }, rest)), helper && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-xs)',
      color: labelColor
    }
  }, helper));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Switch — a compact on/off toggle. Clay track when on, vellum when off.
 * Controlled via `checked` + `onChange`.
 */
function Switch({
  checked = false,
  onChange,
  disabled = false,
  style,
  ...rest
}) {
  const W = 40,
    H = 22,
    KNOB = 16,
    PAD = 3;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    role: "switch",
    "aria-checked": checked,
    disabled: disabled,
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      position: 'relative',
      width: W,
      height: H,
      flex: 'none',
      borderRadius: 'var(--radius-pill)',
      border: '1px solid',
      borderColor: checked ? 'var(--clay)' : 'var(--line)',
      background: checked ? 'var(--clay)' : 'var(--vellum)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      padding: 0,
      transition: 'background var(--dur-base) var(--ease-standard), border-color var(--dur-base) var(--ease-standard)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: PAD - 1,
      left: checked ? W - KNOB - PAD - 1 : PAD - 1,
      width: KNOB,
      height: KNOB,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--paper-soft)',
      boxShadow: '0 1px 2px rgba(23,21,19,0.3)',
      transition: 'left var(--dur-base) var(--ease-standard)'
    }
  }));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NexusHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NexusHeader — the fixed top chrome. Shows the STARQ · NEXUS wordmark (or a back
 * button), an optional domain // title telemetry line, and a right-side live
 * clock + status tag. A thin clay scan-line sits under it.
 */
function NexusHeader({
  title,
  domain,
  subtitle = 'SYS_ON',
  clock,
  onBack,
  backLabel = 'BACK',
  right,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--charcoal)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 54,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 var(--gutter)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      gap: 3
    }
  }, onBack ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onBack,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      alignSelf: 'flex-start',
      background: 'var(--charcoal-soft)',
      border: '1px solid var(--clay)',
      borderRadius: 'var(--radius-xs)',
      padding: '5px 10px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-xs)',
      fontWeight: 700,
      letterSpacing: 'var(--tracking-wide)',
      color: 'var(--clay)',
      cursor: 'pointer'
    }
  }, `‹ ${backLabel}`) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-md)',
      fontWeight: 700,
      letterSpacing: 'var(--tracking-label)',
      color: 'var(--paper-soft)'
    }
  }, "STARQ ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--clay)'
    }
  }, "\xB7"), " NEXUS"), (domain || title) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-2xs)',
      fontWeight: 700,
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color: 'var(--muted-dark)'
    }
  }, domain && /*#__PURE__*/React.createElement(React.Fragment, null, domain, " ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--clay)'
    }
  }, "//"), " "), title)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-end',
      gap: 2
    }
  }, right || /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      fontWeight: 700,
      color: 'var(--clay)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, clock || '09:24:51'), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-2xs)',
      fontWeight: 700,
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color: 'var(--muted-dark)'
    }
  }, subtitle)))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--clay)',
      opacity: 0.25
    }
  }));
}
Object.assign(__ds_scope, { NexusHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NexusHeader.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TabBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TabBar — the fixed bottom navigation. Text-only (a load-bearing brand rule:
 * no icons, no emoji). Active tab brightens + bolds with a short clay indicator.
 */
const DEFAULT_TABS = [{
  id: 'home',
  label: 'Home'
}, {
  id: 'notes',
  label: 'Notes'
}, {
  id: 'calendar',
  label: 'Calendar'
}, {
  id: 'files',
  label: 'Files'
}, {
  id: 'library',
  label: 'Library'
}, {
  id: 'settings',
  label: 'Settings'
}];
function TabBar({
  tabs = DEFAULT_TABS,
  active,
  onChange,
  style,
  ...rest
}) {
  const current = active || tabs[0]?.id;
  return /*#__PURE__*/React.createElement("nav", _extends({
    style: {
      display: 'flex',
      background: 'var(--charcoal-soft)',
      borderTop: '1px solid var(--charcoal-line)',
      padding: '6px 0 8px',
      ...style
    }
  }, rest), tabs.map(tab => {
    const isActive = tab.id === current;
    return /*#__PURE__*/React.createElement("button", {
      key: tab.id,
      type: "button",
      onClick: () => onChange && onChange(tab.id),
      style: {
        position: 'relative',
        flex: 1,
        background: 'none',
        border: 'none',
        padding: '6px 2px',
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--text-xs)',
        fontWeight: isActive ? 700 : 500,
        color: isActive ? 'var(--paper-soft)' : 'var(--muted-dark)',
        cursor: 'pointer',
        transition: 'color var(--dur-base) var(--ease-standard)'
      }
    }, isActive && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: -6,
        left: '50%',
        transform: 'translateX(-50%)',
        width: 20,
        height: 3,
        borderRadius: 'var(--radius-pill)',
        background: 'var(--clay)'
      }
    }), tab.label);
  }));
}
Object.assign(__ds_scope, { TabBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TabBar.jsx", error: String((e && e.message) || e) }); }

// components/reimagined/RzBadge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * RzBadge — the reimagined mono status pill. Accent by default; warn/success/
 * danger map to theme status tokens. Theme-adopting via --rz-*.
 */
const RZ_TONES = {
  accent: {
    c: 'var(--rz-accent)',
    b: 'color-mix(in srgb, var(--rz-accent) 45%, transparent)',
    f: 'color-mix(in srgb, var(--rz-accent) 12%, transparent)'
  },
  warn: {
    c: 'var(--rz-warning)',
    b: 'color-mix(in srgb, var(--rz-warning) 45%, transparent)',
    f: 'color-mix(in srgb, var(--rz-warning) 12%, transparent)'
  },
  success: {
    c: 'var(--rz-success)',
    b: 'color-mix(in srgb, var(--rz-success) 45%, transparent)',
    f: 'color-mix(in srgb, var(--rz-success) 12%, transparent)'
  },
  danger: {
    c: 'var(--rz-danger)',
    b: 'color-mix(in srgb, var(--rz-danger) 45%, transparent)',
    f: 'color-mix(in srgb, var(--rz-danger) 12%, transparent)'
  },
  muted: {
    c: 'var(--rz-muted)',
    b: 'var(--rz-line)',
    f: 'var(--rz-panel-2)'
  }
};
function RzBadge({
  tone = 'accent',
  children,
  style,
  ...rest
}) {
  const t = RZ_TONES[tone] || RZ_TONES.accent;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      fontFamily: 'var(--rz-mono)',
      fontSize: 9,
      fontWeight: 700,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      padding: '3px 8px',
      borderRadius: 999,
      border: `1px solid ${t.b}`,
      color: t.c,
      background: t.f,
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { RzBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/reimagined/RzBadge.jsx", error: String((e && e.message) || e) }); }

// components/reimagined/RzButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * RzButton — the reimagined action control. Accent-filled, outline, or ghost.
 * Consumes --rz-* tokens (theme-adopting). Square-ish per theme radius.
 */
const RZ_VARIANTS = {
  accent: {
    background: 'var(--rz-accent)',
    color: 'var(--rz-on-accent)',
    border: '1px solid var(--rz-accent)'
  },
  outline: {
    background: 'transparent',
    color: 'var(--rz-accent)',
    border: '1px solid color-mix(in srgb, var(--rz-accent) 50%, transparent)'
  },
  ghost: {
    background: 'var(--rz-panel)',
    color: 'var(--rz-text-dim)',
    border: '1px solid var(--rz-line)'
  }
};
const RZ_SIZES = {
  sm: {
    padding: '7px 14px',
    fontSize: 11
  },
  md: {
    padding: '10px 18px',
    fontSize: 12.5
  }
};
function RzButton({
  variant = 'accent',
  size = 'md',
  mono = true,
  disabled = false,
  children,
  style,
  ...rest
}) {
  const v = RZ_VARIANTS[variant] || RZ_VARIANTS.accent;
  const s = RZ_SIZES[size] || RZ_SIZES.md;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      fontFamily: mono ? 'var(--rz-mono)' : 'var(--rz-display)',
      fontWeight: 700,
      letterSpacing: mono ? '0.08em' : '0.01em',
      textTransform: mono ? 'uppercase' : 'none',
      borderRadius: 'var(--rz-radius-sm)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      lineHeight: 1,
      transition: 'filter .14s var(--rz-ease), transform .14s var(--rz-ease)',
      ...s,
      ...v,
      ...style
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = 'scale(0.97)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = 'scale(1)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
      e.currentTarget.style.filter = 'none';
    },
    onMouseEnter: e => {
      if (!disabled) e.currentTarget.style.filter = 'brightness(1.08)';
    }
  }, rest), children);
}
Object.assign(__ds_scope, { RzButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/reimagined/RzButton.jsx", error: String((e && e.message) || e) }); }

// components/reimagined/RzNeonMark.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * RzNeonMark — the reimagined 1950s neon-cursive starqOS wordmark. Bright
 * near-white core, deep accent bloom (layered text-shadow), subtle hum + flicker.
 * Re-tints to the active theme via --rz-accent. Web-only glow; see the handoff
 * README for the React Native substitute.
 */
function RzNeonMark({
  text = 'starqOS',
  size = 34,
  animate = true,
  style,
  ...rest
}) {
  const shadow = ['0 0 3px #fff', '0 0 8px color-mix(in srgb, var(--rz-accent) 90%, #fff)', '0 0 16px var(--rz-accent)', '0 0 30px var(--rz-accent)', '0 0 52px var(--rz-accent)'].join(', ');
  // split so a couple of glyphs can flicker independently
  const chars = String(text).split('');
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      fontFamily: "'Yellowtail', cursive",
      fontSize: size,
      lineHeight: 1,
      color: '#fff',
      paddingRight: 6,
      textShadow: shadow,
      animation: animate ? 'rz-hum 4s infinite alternate' : 'none',
      ...style
    }
  }, rest), chars.map((c, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: animate && (i === 3 || i === chars.length - 1) ? {
      animation: `rz-flicker ${i === 3 ? 6.5 : 7.7}s infinite ${i === 3 ? 1.2 : 0}s`
    } : undefined
  }, c)), /*#__PURE__*/React.createElement("style", null, `
        @keyframes rz-hum {0%,100%{filter:brightness(1)}49%{filter:brightness(1.05)}50%{filter:brightness(.9)}51%{filter:brightness(1.04)}}
        @keyframes rz-flicker {0%,93%,100%{opacity:1}94%{opacity:.3}95%{opacity:.9}96%{opacity:.4}97%{opacity:1}}
        @media (prefers-reduced-motion: reduce){ [style*="rz-hum"],[style*="rz-flicker"]{animation:none!important} }
      `));
}
Object.assign(__ds_scope, { RzNeonMark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/reimagined/RzNeonMark.jsx", error: String((e && e.message) || e) }); }

// components/reimagined/RzPanel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * RzPanel — the reimagined bordered surface. Consumes --rz-* tokens, so it
 * adopts whatever [data-rz-theme] ancestor wraps it. Optional mono section label
 * (rendered above the panel) and theme treatments (grid/glow) come from CSS.
 */
function RzPanel({
  label,
  pad = false,
  children,
  style,
  bodyStyle,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", rest, label && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      marginBottom: 9
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--rz-mono)',
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: '0.2em',
      textTransform: 'uppercase',
      color: 'var(--rz-muted)',
      whiteSpace: 'nowrap'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: 'var(--rz-line)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--rz-line)',
      background: 'var(--rz-panel)',
      borderRadius: 'var(--rz-radius-sm)',
      overflow: 'hidden',
      ...(pad ? {
        padding: 14
      } : null),
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: bodyStyle
  }, children)));
}

/** RzPanelRow — a single divided row inside an RzPanel list. */
function RzPanelRow({
  kicker,
  value,
  right,
  last = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 10,
      padding: '11px 13px',
      borderBottom: last ? 'none' : '1px solid var(--rz-line)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 3,
      minWidth: 0
    }
  }, kicker && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--rz-mono)',
      fontSize: 8.5,
      fontWeight: 700,
      letterSpacing: '0.16em',
      textTransform: 'uppercase',
      color: 'var(--rz-muted)'
    }
  }, kicker), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13.5,
      fontWeight: 600,
      color: 'var(--rz-text)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, value)), right && /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 'none'
    }
  }, right));
}
Object.assign(__ds_scope, { RzPanel, RzPanelRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/reimagined/RzPanel.jsx", error: String((e && e.message) || e) }); }

// components/reimagined/RzProgress.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * RzProgress — the reimagined thin progress track. Accent fill, glow in themes
 * that define --rz-glow (Plasma). Theme-adopting via --rz-*.
 */
function RzProgress({
  value = 0,
  style,
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, value));
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "progressbar",
    "aria-valuenow": pct,
    "aria-valuemin": 0,
    "aria-valuemax": 100,
    style: {
      height: 'var(--rz-track)',
      borderRadius: 999,
      background: 'var(--rz-panel-2)',
      overflow: 'hidden',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      width: `${pct}%`,
      borderRadius: 999,
      background: 'var(--rz-accent)',
      boxShadow: '0 0 10px color-mix(in srgb, var(--rz-accent) 60%, transparent)',
      transition: 'width .24s var(--rz-ease)'
    }
  }));
}
Object.assign(__ds_scope, { RzProgress });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/reimagined/RzProgress.jsx", error: String((e && e.message) || e) }); }

// components/reimagined/RzStat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * RzStat — a reimagined mono metric: a big tabular value over a small mono label.
 * Used in the System grid and DB dashboard. Theme-adopting via --rz-*.
 */
function RzStat({
  value,
  label,
  size = 'md',
  style,
  ...rest
}) {
  const fs = size === 'lg' ? 24 : size === 'sm' ? 12 : 16;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 5,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--rz-mono)',
      fontWeight: 700,
      fontSize: fs,
      color: 'var(--rz-text)',
      fontVariantNumeric: 'tabular-nums',
      lineHeight: 1
    }
  }, value), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--rz-mono)',
      fontSize: 7.5,
      fontWeight: 700,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--rz-muted)'
    }
  }, label));
}

/** RzCell — RzStat wrapped in a bordered grid cell (the System/DB tiles). */
function RzCell({
  value,
  label,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      border: '1px solid var(--rz-line)',
      background: 'var(--rz-panel)',
      borderRadius: 'var(--rz-radius-sm)',
      padding: '10px 5px',
      textAlign: 'center',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(RzStat, {
    value: value,
    label: label,
    size: "sm"
  }));
}
Object.assign(__ds_scope, { RzStat, RzCell });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/reimagined/RzStat.jsx", error: String((e && e.message) || e) }); }

// components/reimagined/RzTabBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * RzTabBar — the reimagined fixed bottom nav. Text-only tabs; the active tab
 * brightens + bolds with a glowing accent indicator bar. Theme-adopting.
 */
const RZ_DEFAULT_TABS = [{
  id: 'home',
  label: 'Home'
}, {
  id: 'work',
  label: 'Work'
}, {
  id: 'library',
  label: 'Library'
}, {
  id: 'settings',
  label: 'Settings'
}];
function RzTabBar({
  tabs = RZ_DEFAULT_TABS,
  active,
  onChange,
  style,
  ...rest
}) {
  const current = active || tabs[0]?.id;
  return /*#__PURE__*/React.createElement("nav", _extends({
    style: {
      display: 'flex',
      background: 'var(--rz-panel)',
      borderTop: '1px solid var(--rz-line)',
      padding: '8px 0 10px',
      ...style
    }
  }, rest), tabs.map(tab => {
    const on = tab.id === current;
    return /*#__PURE__*/React.createElement("button", {
      key: tab.id,
      type: "button",
      onClick: () => onChange && onChange(tab.id),
      style: {
        position: 'relative',
        flex: 1,
        background: 'none',
        border: 'none',
        padding: '6px 2px',
        fontFamily: 'var(--rz-display)',
        fontSize: 11.5,
        fontWeight: on ? 700 : 500,
        color: on ? 'var(--rz-text)' : 'var(--rz-muted)',
        cursor: 'pointer',
        transition: 'color .2s var(--rz-ease)'
      }
    }, on && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: -8,
        left: '50%',
        transform: 'translateX(-50%)',
        width: 20,
        height: 3,
        borderRadius: 999,
        background: 'var(--rz-accent)',
        boxShadow: '0 0 8px var(--rz-accent)'
      }
    }), tab.label);
  }));
}
Object.assign(__ds_scope, { RzTabBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/reimagined/RzTabBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/starq-nexus-mobile/HomeScreen.jsx
try { (() => {
// HomeScreen.jsx — starqOS HUD home (web recreation)
// Reads DS primitives off the global namespace; exports itself to window.
const {
  HudLabel: H_HudLabel,
  MetricStat: H_Metric
} = window.StarqOSDesignSystem_83c734;
const homeStyles = {
  shell: {
    background: 'var(--charcoal)',
    minHeight: '100%',
    paddingBottom: 20
  },
  hero: {
    padding: '18px 16px 8px'
  },
  topBar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 40,
    marginBottom: 16
  },
  logoRow: {
    display: 'flex',
    alignItems: 'center',
    gap: 12
  },
  ham: {
    display: 'flex',
    flexDirection: 'column',
    gap: 4,
    width: 22,
    cursor: 'pointer'
  },
  hamLine: {
    height: 2,
    borderRadius: 1,
    background: 'var(--paper-soft)'
  },
  logo: {
    fontFamily: 'var(--font-sans)',
    fontSize: 28,
    fontWeight: 700,
    color: 'var(--paper-soft)'
  },
  statusBadge: {
    display: 'flex',
    alignItems: 'center',
    gap: 6,
    background: 'var(--charcoal-soft)',
    border: '1px solid var(--charcoal-line)',
    padding: '4px 8px',
    borderRadius: 'var(--radius-xs)'
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 999,
    background: 'var(--success)'
  },
  statusText: {
    fontFamily: 'var(--font-sans)',
    fontSize: 10,
    fontWeight: 700,
    letterSpacing: '0.08em',
    color: 'var(--paper-soft)'
  },
  timeBlock: {
    background: 'var(--charcoal-2)',
    border: '1px solid var(--charcoal-line)',
    borderRadius: 'var(--radius-sm)',
    padding: 16,
    marginBottom: 20,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center'
  },
  bigTime: {
    fontFamily: 'var(--font-sans)',
    fontSize: 46,
    fontWeight: 700,
    color: 'var(--paper-soft)',
    letterSpacing: 1,
    fontVariantNumeric: 'tabular-nums',
    lineHeight: 1
  },
  dateRow: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    marginTop: 8
  },
  dayText: {
    fontSize: 11,
    fontWeight: 700,
    color: 'var(--clay)',
    letterSpacing: '0.12em'
  },
  dateDiv: {
    fontSize: 11,
    color: 'var(--charcoal-line)'
  },
  dateText: {
    fontSize: 11,
    color: 'var(--muted-dark)',
    letterSpacing: '0.08em'
  },
  section: {
    marginBottom: 20
  },
  sectionHead: {
    marginBottom: 10
  },
  panel: {
    background: 'var(--charcoal-soft)',
    border: '1px solid var(--charcoal-line)',
    borderRadius: 'var(--radius-sm)',
    padding: 4
  },
  item: {
    padding: '10px 12px',
    borderBottom: '1px solid var(--charcoal-divider)'
  },
  itemLabel: {
    fontSize: 9,
    fontWeight: 700,
    color: 'var(--muted)',
    letterSpacing: '0.12em'
  },
  itemValue: {
    fontSize: 14,
    fontWeight: 700,
    color: 'var(--paper-soft)',
    marginTop: 4
  },
  itemTime: {
    fontSize: 11,
    color: 'var(--clay)',
    marginTop: 3
  },
  captureRow: {
    display: 'flex',
    gap: 8,
    marginBottom: 8
  },
  captureBtn: {
    flex: 1,
    border: '1px solid var(--charcoal-line)',
    background: 'var(--charcoal-soft)',
    padding: '10px 0',
    textAlign: 'center',
    borderRadius: 'var(--radius-xs)',
    color: 'var(--paper-soft)',
    fontSize: 11,
    fontWeight: 700,
    letterSpacing: '0.08em',
    cursor: 'pointer'
  },
  notesPanel: {
    background: 'var(--charcoal-soft)',
    border: '1px solid var(--charcoal-line)',
    borderRadius: 'var(--radius-sm)',
    padding: 12
  },
  noteRow: {
    display: 'flex',
    gap: 8,
    marginBottom: 8
  },
  noteBullet: {
    color: 'var(--clay)',
    fontWeight: 700,
    fontSize: 14,
    lineHeight: 1.3
  },
  noteTitle: {
    fontSize: 13,
    fontWeight: 700,
    color: 'var(--paper-soft)'
  },
  noteMeta: {
    fontSize: 11,
    color: 'var(--muted-dark)',
    marginTop: 2
  },
  projRow: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '10px 12px',
    borderBottom: '1px solid var(--charcoal-divider)'
  },
  projLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: 8
  },
  projSquare: {
    fontSize: 10,
    lineHeight: 1
  },
  projName: {
    fontSize: 13,
    fontWeight: 700,
    color: 'var(--paper-soft)'
  },
  projDetail: {
    fontSize: 12,
    color: 'var(--muted-dark)'
  },
  sysGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4, 1fr)',
    gap: 6
  },
  sysBox: {
    border: '1px solid var(--charcoal-line)',
    background: 'var(--charcoal-soft)',
    padding: 8,
    borderRadius: 'var(--radius-xs)',
    textAlign: 'center'
  },
  sysLabel: {
    fontSize: 8,
    fontWeight: 700,
    color: 'var(--muted)',
    letterSpacing: '0.1em'
  },
  sysVal: {
    fontSize: 10,
    fontWeight: 700,
    color: 'var(--paper-soft)',
    marginTop: 3
  }
};
function HomeScreen({
  onOpenDrawer
}) {
  const [now, setNow] = React.useState(new Date());
  React.useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  const hh = String(now.getHours()).padStart(2, '0');
  const mm = String(now.getMinutes()).padStart(2, '0');
  const ss = String(now.getSeconds()).padStart(2, '0');
  const day = now.toLocaleDateString([], {
    weekday: 'long'
  }).toUpperCase();
  const date = now.toLocaleDateString([], {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  }).toUpperCase();
  const clk = now.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });
  const S = homeStyles;
  return /*#__PURE__*/React.createElement("div", {
    style: S.shell
  }, /*#__PURE__*/React.createElement("div", {
    style: S.hero
  }, /*#__PURE__*/React.createElement("div", {
    style: S.topBar
  }, /*#__PURE__*/React.createElement("div", {
    style: S.logoRow
  }, /*#__PURE__*/React.createElement("div", {
    style: S.ham,
    onClick: onOpenDrawer
  }, /*#__PURE__*/React.createElement("span", {
    style: S.hamLine
  }), /*#__PURE__*/React.createElement("span", {
    style: S.hamLine
  }), /*#__PURE__*/React.createElement("span", {
    style: S.hamLine
  })), /*#__PURE__*/React.createElement("span", {
    style: S.logo
  }, "starqOS")), /*#__PURE__*/React.createElement("div", {
    style: S.statusBadge
  }, /*#__PURE__*/React.createElement("span", {
    style: S.statusDot
  }), /*#__PURE__*/React.createElement("span", {
    style: S.statusText
  }, "SYS_ON"))), /*#__PURE__*/React.createElement("div", {
    style: S.timeBlock
  }, /*#__PURE__*/React.createElement("span", {
    style: S.bigTime
  }, hh, ":", mm, ":", ss), /*#__PURE__*/React.createElement("div", {
    style: S.dateRow
  }, /*#__PURE__*/React.createElement("span", {
    style: S.dayText
  }, day), /*#__PURE__*/React.createElement("span", {
    style: S.dateDiv
  }, "|"), /*#__PURE__*/React.createElement("span", {
    style: S.dateText
  }, date))), /*#__PURE__*/React.createElement("div", {
    style: S.section
  }, /*#__PURE__*/React.createElement("div", {
    style: S.sectionHead
  }, /*#__PURE__*/React.createElement(H_HudLabel, {
    bracket: true,
    tone: "vellum"
  }, "Today's commitments")), /*#__PURE__*/React.createElement("div", {
    style: S.panel
  }, /*#__PURE__*/React.createElement("div", {
    style: S.item
  }, /*#__PURE__*/React.createElement("div", {
    style: S.itemLabel
  }, "APPOINTMENT"), /*#__PURE__*/React.createElement("div", {
    style: S.itemValue
  }, "Review weekly budget spreadsheet"), /*#__PURE__*/React.createElement("div", {
    style: S.itemTime
  }, "Jun 9 \xB7 20:00")), /*#__PURE__*/React.createElement("div", {
    style: S.item
  }, /*#__PURE__*/React.createElement("div", {
    style: S.itemLabel
  }, "STUDY SESSION"), /*#__PURE__*/React.createElement("div", {
    style: S.itemValue
  }, "IBP Coursework review"), /*#__PURE__*/React.createElement("div", {
    style: S.itemTime
  }, "Jun 13 \xB7 14:00")), /*#__PURE__*/React.createElement("div", {
    style: S.item
  }, /*#__PURE__*/React.createElement("div", {
    style: S.itemLabel
  }, "NEXT TASK"), /*#__PURE__*/React.createElement("div", {
    style: S.itemValue
  }, "[Antrac ERP] Procurement module spec")), /*#__PURE__*/React.createElement("div", {
    style: {
      ...S.item,
      borderBottom: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: S.itemLabel
  }, "DEADLINE"), /*#__PURE__*/React.createElement("div", {
    style: {
      ...S.itemValue,
      color: 'var(--clay)'
    }
  }, "IBP Coursework Exam"), /*#__PURE__*/React.createElement("div", {
    style: S.itemTime
  }, "Jun 14 \xB7 09:00")))), /*#__PURE__*/React.createElement("div", {
    style: S.section
  }, /*#__PURE__*/React.createElement("div", {
    style: S.sectionHead
  }, /*#__PURE__*/React.createElement(H_HudLabel, {
    bracket: true,
    tone: "vellum"
  }, "Quick capture")), /*#__PURE__*/React.createElement("div", {
    style: S.captureRow
  }, /*#__PURE__*/React.createElement("div", {
    style: S.captureBtn
  }, "+ NEW NOTE"), /*#__PURE__*/React.createElement("div", {
    style: S.captureBtn
  }, "OPEN NOTES")), /*#__PURE__*/React.createElement("div", {
    style: S.notesPanel
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...S.itemLabel,
      marginBottom: 8
    }
  }, "RECENT NOTES"), /*#__PURE__*/React.createElement("div", {
    style: S.noteRow
  }, /*#__PURE__*/React.createElement("span", {
    style: S.noteBullet
  }, "\xBB"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: S.noteTitle
  }, "Hoadha SCM Roadmap Goals"), /*#__PURE__*/React.createElement("div", {
    style: S.noteMeta
  }, "Work \xB7 Jun 12"))), /*#__PURE__*/React.createElement("div", {
    style: S.noteRow
  }, /*#__PURE__*/React.createElement("span", {
    style: S.noteBullet
  }, "\xBB"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: S.noteTitle
  }, "Scenario Planning Stages outline"), /*#__PURE__*/React.createElement("div", {
    style: S.noteMeta
  }, "Study \xB7 Jun 11"))))), /*#__PURE__*/React.createElement("div", {
    style: S.section
  }, /*#__PURE__*/React.createElement("div", {
    style: S.sectionHead
  }, /*#__PURE__*/React.createElement(H_HudLabel, {
    bracket: true,
    tone: "vellum"
  }, "Active projects")), /*#__PURE__*/React.createElement("div", {
    style: S.panel
  }, /*#__PURE__*/React.createElement("div", {
    style: S.projRow
  }, /*#__PURE__*/React.createElement("div", {
    style: S.projLeft
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      ...S.projSquare,
      color: 'var(--domain-workers)'
    }
  }, "\u25A0"), /*#__PURE__*/React.createElement("span", {
    style: S.projName
  }, "Antrac ERP")), /*#__PURE__*/React.createElement("span", {
    style: S.projDetail
  }, "24 Tasks (48%)")), /*#__PURE__*/React.createElement("div", {
    style: S.projRow
  }, /*#__PURE__*/React.createElement("div", {
    style: S.projLeft
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      ...S.projSquare,
      color: 'var(--domain-knowledge)'
    }
  }, "\u25A0"), /*#__PURE__*/React.createElement("span", {
    style: S.projName
  }, "Hoadha")), /*#__PURE__*/React.createElement("span", {
    style: S.projDetail
  }, "50 Tasks (62%)")), /*#__PURE__*/React.createElement("div", {
    style: {
      ...S.projRow,
      borderBottom: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: S.projLeft
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      ...S.projSquare,
      color: 'var(--domain-orgs)'
    }
  }, "\u25A0"), /*#__PURE__*/React.createElement("span", {
    style: S.projName
  }, "OrgSync")), /*#__PURE__*/React.createElement("span", {
    style: S.projDetail
  }, "18 Tasks (33%)")))), /*#__PURE__*/React.createElement("div", {
    style: S.section
  }, /*#__PURE__*/React.createElement("div", {
    style: S.sectionHead
  }, /*#__PURE__*/React.createElement(H_HudLabel, {
    bracket: true,
    tone: "vellum"
  }, "System HUD")), /*#__PURE__*/React.createElement("div", {
    style: S.sysGrid
  }, /*#__PURE__*/React.createElement("div", {
    style: S.sysBox
  }, /*#__PURE__*/React.createElement("div", {
    style: S.sysLabel
  }, "LIBRARY"), /*#__PURE__*/React.createElement("div", {
    style: S.sysVal
  }, "1,127 REC")), /*#__PURE__*/React.createElement("div", {
    style: S.sysBox
  }, /*#__PURE__*/React.createElement("div", {
    style: S.sysLabel
  }, "WORKERS"), /*#__PURE__*/React.createElement("div", {
    style: S.sysVal
  }, "4 ACT")), /*#__PURE__*/React.createElement("div", {
    style: S.sysBox
  }, /*#__PURE__*/React.createElement("div", {
    style: S.sysLabel
  }, "SYNC"), /*#__PURE__*/React.createElement("div", {
    style: S.sysVal
  }, "SSOT OK")), /*#__PURE__*/React.createElement("div", {
    style: S.sysBox
  }, /*#__PURE__*/React.createElement("div", {
    style: S.sysLabel
  }, "UPDATED"), /*#__PURE__*/React.createElement("div", {
    style: S.sysVal
  }, clk))))));
}
window.HomeScreen = HomeScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/starq-nexus-mobile/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/starq-nexus-mobile/LibraryScreen.jsx
try { (() => {
// LibraryScreen.jsx — starqOS knowledge vault (web recreation)
const {
  NexusHeader: L_Header,
  Badge: L_Badge,
  HudLabel: L_Hud
} = window.StarqOSDesignSystem_83c734;
const libStyles = {
  shell: {
    background: 'var(--charcoal)',
    minHeight: '100%'
  },
  content: {
    padding: '16px 16px 24px'
  },
  intro: {
    fontSize: 13,
    color: 'var(--muted-dark)',
    lineHeight: 1.5,
    marginBottom: 16
  },
  catGrid: {
    display: 'flex',
    flexDirection: 'column',
    gap: 10,
    marginBottom: 22
  },
  catCard: {
    background: 'var(--paper)',
    border: '1px solid var(--line)',
    borderRadius: 'var(--radius-sm)',
    padding: 13,
    boxShadow: 'var(--shadow-card)'
  },
  catTop: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    gap: 12
  },
  catLabel: {
    fontSize: 18,
    fontWeight: 700,
    color: 'var(--ink)'
  },
  catFolder: {
    marginTop: 4,
    color: 'var(--clay-dark)',
    fontSize: 12,
    fontWeight: 700
  },
  catCount: {
    fontSize: 11,
    fontWeight: 700,
    color: 'var(--muted)',
    letterSpacing: '0.08em',
    whiteSpace: 'nowrap'
  },
  catDesc: {
    marginTop: 8,
    color: 'var(--muted)',
    fontSize: 13,
    lineHeight: 1.45
  },
  recList: {
    display: 'flex',
    flexDirection: 'column',
    gap: 10
  },
  recCard: {
    background: 'var(--paper)',
    border: '1px solid var(--line)',
    borderRadius: 'var(--radius-sm)',
    padding: 14,
    boxShadow: 'var(--shadow-card)'
  },
  recTop: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8
  },
  recDate: {
    color: 'var(--clay-dark)',
    fontSize: 11,
    fontWeight: 700
  },
  recTitle: {
    color: 'var(--ink)',
    fontSize: 16,
    fontWeight: 700,
    lineHeight: 1.25,
    marginBottom: 6
  },
  recSummary: {
    color: 'var(--muted)',
    fontSize: 13,
    lineHeight: 1.45
  }
};
const LIB_CATS = [{
  label: 'Knowledge',
  folder: '/knowledge',
  count: 612,
  desc: 'Synced markdown notes, references and distilled research from the graph.'
}, {
  label: 'Academia',
  folder: '/academia',
  count: 268,
  desc: 'Course material, exam prep, diagnostics and the Athena study integrator.'
}, {
  label: 'Projects',
  folder: '/projects',
  count: 184,
  desc: 'Specs, roadmaps and audit reports for active STARQ ventures.'
}, {
  label: 'Life',
  folder: '/life',
  count: 63,
  desc: 'Finance, health and personal operating documents.'
}];
const LIB_RECS = [{
  title: 'Hoadha SCM Roadmap — Sprint 5 Gate',
  date: 'Jun 12',
  cat: 'Projects',
  tone: 'clay',
  summary: 'DHIV-S2-GATE milestones, marketplace data migration and Male island seeding.'
}, {
  title: 'Scenario Planning — 11 Stages',
  date: 'Jun 11',
  cat: 'Academia',
  tone: 'success',
  summary: 'Critical-thinking exam prep; inductive-fallacy gaps flagged for review.'
}, {
  title: 'Antrac ERP — Procurement & Fleet',
  date: 'Jun 10',
  cat: 'Projects',
  tone: 'clay',
  summary: 'Module spec for the procurement workflow and fleet digital-twin roles.'
}];
function LibraryScreen() {
  const S = libStyles;
  return /*#__PURE__*/React.createElement("div", {
    style: S.shell
  }, /*#__PURE__*/React.createElement(L_Header, {
    domain: "Vault",
    title: "Library",
    subtitle: "VAULT_RECORDS"
  }), /*#__PURE__*/React.createElement("div", {
    style: S.content
  }, /*#__PURE__*/React.createElement("p", {
    style: S.intro
  }, "The synced knowledge vault. Browse by category or open a record in the reader."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement(L_Hud, {
    bracket: true,
    tone: "vellum"
  }, "Categories")), /*#__PURE__*/React.createElement("div", {
    style: S.catGrid
  }, LIB_CATS.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.label,
    style: S.catCard
  }, /*#__PURE__*/React.createElement("div", {
    style: S.catTop
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: S.catLabel
  }, c.label), /*#__PURE__*/React.createElement("div", {
    style: S.catFolder
  }, c.folder)), /*#__PURE__*/React.createElement("span", {
    style: S.catCount
  }, c.count, " REC \u203A")), /*#__PURE__*/React.createElement("div", {
    style: S.catDesc
  }, c.desc)))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement(L_Hud, {
    bracket: true,
    tone: "vellum"
  }, "Recent records")), /*#__PURE__*/React.createElement("div", {
    style: S.recList
  }, LIB_RECS.map(r => /*#__PURE__*/React.createElement("div", {
    key: r.title,
    style: S.recCard
  }, /*#__PURE__*/React.createElement("div", {
    style: S.recTop
  }, /*#__PURE__*/React.createElement(L_Badge, {
    tone: r.tone
  }, r.cat), /*#__PURE__*/React.createElement("span", {
    style: S.recDate
  }, r.date)), /*#__PURE__*/React.createElement("div", {
    style: S.recTitle
  }, r.title), /*#__PURE__*/React.createElement("div", {
    style: S.recSummary
  }, r.summary))))));
}
window.LibraryScreen = LibraryScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/starq-nexus-mobile/LibraryScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/starq-nexus-mobile/ProjectsScreen.jsx
try { (() => {
// ProjectsScreen.jsx — starqOS project subapp with Kanban board (web recreation)
const {
  NexusHeader: P_Header,
  Badge: P_Badge,
  ProgressBar: P_Progress,
  HudLabel: P_Hud
} = window.StarqOSDesignSystem_83c734;
const COLS = [{
  id: 'Backlog',
  tone: 'muted'
}, {
  id: 'Doing',
  tone: 'clay'
}, {
  id: 'Review',
  tone: 'warning'
}, {
  id: 'Done',
  tone: 'success'
}];
const PROJECTS = [{
  id: 'hoadha',
  name: 'Hoadha',
  sub: 'Marketplace · Venture',
  pct: 62,
  domain: 'var(--domain-knowledge)'
}, {
  id: 'antrac-erp',
  name: 'Antrac ERP',
  sub: 'Software Engineering',
  pct: 48,
  domain: 'var(--domain-workers)'
}, {
  id: 'orgsync',
  name: 'OrgSync',
  sub: 'Digital Twin · Ops',
  pct: 33,
  domain: 'var(--domain-orgs)'
}];
const BOARD = {
  hoadha: {
    Backlog: [{
      id: 'DHIV-31',
      t: 'Seed Male island categories',
      n: 'Sprint 5'
    }, {
      id: 'DHIV-34',
      t: 'Vendor onboarding flow',
      n: 'Capture'
    }],
    Doing: [{
      id: 'DHIV-22',
      t: 'Marketplace data migration',
      n: 'DB'
    }],
    Review: [{
      id: 'DHIV-19',
      t: 'Listing search index',
      n: 'Perf'
    }],
    Done: [{
      id: 'DHIV-12',
      t: 'Auth & roles',
      n: 'Done'
    }, {
      id: 'DHIV-08',
      t: 'Schema v2',
      n: 'Done'
    }]
  }
};
const projStyles = {
  shell: {
    background: 'var(--charcoal)',
    minHeight: '100%'
  },
  content: {
    padding: '16px 0 24px'
  },
  pad: {
    padding: '0 16px'
  },
  projList: {
    display: 'flex',
    flexDirection: 'column',
    gap: 10,
    marginBottom: 20
  },
  projCard: active => ({
    background: 'var(--charcoal-soft)',
    border: `1px solid ${active ? 'var(--clay)' : 'var(--charcoal-line)'}`,
    borderRadius: 'var(--radius-sm)',
    padding: 12,
    cursor: 'pointer',
    position: 'relative',
    overflow: 'hidden'
  }),
  stripe: c => ({
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 3,
    background: c
  }),
  projRowTop: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8
  },
  projName: {
    fontSize: 15,
    fontWeight: 700,
    color: 'var(--paper-soft)'
  },
  projSub: {
    fontSize: 11,
    color: 'var(--muted-dark)',
    marginTop: 2
  },
  pct: {
    fontSize: 13,
    fontWeight: 700,
    color: 'var(--clay)',
    fontVariantNumeric: 'tabular-nums'
  },
  boardScroll: {
    display: 'flex',
    gap: 12,
    overflowX: 'auto',
    padding: '0 16px 8px',
    scrollSnapType: 'x proximity'
  },
  col: {
    flex: '0 0 200px',
    scrollSnapAlign: 'start'
  },
  colHead: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
    paddingBottom: 6,
    borderBottom: '1px solid var(--charcoal-line)'
  },
  colCount: {
    fontSize: 11,
    fontWeight: 700,
    color: 'var(--muted-dark)'
  },
  taskCard: c => ({
    background: 'var(--charcoal-soft)',
    border: '1px solid var(--charcoal-line)',
    borderLeft: `3px solid ${c}`,
    borderRadius: 'var(--radius-xs)',
    padding: 10,
    marginBottom: 8
  }),
  taskId: {
    fontSize: 9,
    fontWeight: 700,
    color: 'var(--muted-dark)',
    letterSpacing: '0.1em'
  },
  taskTitle: {
    fontSize: 13,
    fontWeight: 600,
    color: 'var(--paper-soft)',
    marginTop: 4,
    lineHeight: 1.3
  },
  taskNote: {
    fontSize: 10,
    color: 'var(--muted-dark)',
    marginTop: 4
  }
};
const TONE_COLOR = {
  muted: 'var(--muted)',
  clay: 'var(--clay)',
  warning: 'var(--warning)',
  success: 'var(--success)'
};
function ProjectsScreen() {
  const [sel, setSel] = React.useState('hoadha');
  const S = projStyles;
  const board = BOARD[sel] || BOARD.hoadha;
  return /*#__PURE__*/React.createElement("div", {
    style: S.shell
  }, /*#__PURE__*/React.createElement(P_Header, {
    domain: "Work",
    title: "Projects",
    subtitle: "SELECT_PROJECT"
  }), /*#__PURE__*/React.createElement("div", {
    style: S.content
  }, /*#__PURE__*/React.createElement("div", {
    style: S.pad
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement(P_Hud, {
    bracket: true,
    tone: "vellum"
  }, "STARQ Technologies")), /*#__PURE__*/React.createElement("div", {
    style: S.projList
  }, PROJECTS.map(p => /*#__PURE__*/React.createElement("div", {
    key: p.id,
    style: S.projCard(sel === p.id),
    onClick: () => setSel(p.id)
  }, /*#__PURE__*/React.createElement("div", {
    style: S.stripe(p.domain)
  }), /*#__PURE__*/React.createElement("div", {
    style: S.projRowTop
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: S.projName
  }, p.name), /*#__PURE__*/React.createElement("div", {
    style: S.projSub
  }, p.sub)), /*#__PURE__*/React.createElement("span", {
    style: S.pct
  }, p.pct, "%")), /*#__PURE__*/React.createElement(P_Progress, {
    value: p.pct,
    dark: true
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      ...S.pad,
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement(P_Hud, {
    bracket: true,
    tone: "vellum"
  }, PROJECTS.find(p => p.id === sel).name, " board")), /*#__PURE__*/React.createElement("div", {
    style: S.boardScroll
  }, COLS.map(col => {
    const tasks = board[col.id] || [];
    return /*#__PURE__*/React.createElement("div", {
      key: col.id,
      style: S.col
    }, /*#__PURE__*/React.createElement("div", {
      style: S.colHead
    }, /*#__PURE__*/React.createElement(P_Badge, {
      tone: col.tone
    }, col.id), /*#__PURE__*/React.createElement("span", {
      style: S.colCount
    }, tasks.length)), tasks.map(t => /*#__PURE__*/React.createElement("div", {
      key: t.id,
      style: S.taskCard(TONE_COLOR[col.tone])
    }, /*#__PURE__*/React.createElement("div", {
      style: S.taskId
    }, t.id), /*#__PURE__*/React.createElement("div", {
      style: S.taskTitle
    }, t.t), /*#__PURE__*/React.createElement("div", {
      style: S.taskNote
    }, t.n))), tasks.length === 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: 'var(--muted-dark)',
        fontStyle: 'italic',
        padding: 8
      }
    }, "Empty"));
  }))));
}
window.ProjectsScreen = ProjectsScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/starq-nexus-mobile/ProjectsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/starq-nexus-mobile/SettingsScreen.jsx
try { (() => {
// SettingsScreen.jsx — starqOS config shell (web recreation)
const {
  NexusHeader: ST_Header,
  Input: ST_Input,
  Switch: ST_Switch,
  Button: ST_Button,
  MetricStat: ST_Metric,
  HudLabel: ST_Hud
} = window.StarqOSDesignSystem_83c734;
const setStyles = {
  shell: {
    background: 'var(--charcoal)',
    minHeight: '100%'
  },
  content: {
    padding: '16px 16px 24px'
  },
  panel: {
    background: 'var(--paper)',
    border: '1px solid var(--line)',
    borderRadius: 'var(--radius-sm)',
    padding: 14,
    marginBottom: 14,
    boxShadow: 'var(--shadow-card)'
  },
  kicker: {
    color: 'var(--clay-dark)',
    fontSize: 12,
    fontWeight: 700,
    letterSpacing: '0.04em'
  },
  title: {
    marginTop: 5,
    color: 'var(--ink)',
    fontSize: 18,
    fontWeight: 700
  },
  text: {
    marginTop: 6,
    color: 'var(--muted)',
    fontSize: 13,
    lineHeight: 1.45,
    marginBottom: 12
  },
  connRow: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    marginTop: 12
  },
  connDot: {
    width: 7,
    height: 7,
    borderRadius: 999,
    background: 'var(--success)'
  },
  connText: {
    fontSize: 11,
    fontWeight: 700,
    letterSpacing: '0.1em',
    textTransform: 'uppercase',
    color: 'var(--success)'
  },
  toggleRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '10px 0',
    borderBottom: '1px solid var(--line)'
  },
  toggleLabel: {
    fontSize: 14,
    fontWeight: 600,
    color: 'var(--ink)'
  },
  toggleSub: {
    fontSize: 12,
    color: 'var(--muted)',
    marginTop: 2
  },
  dbGrid: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr 1fr',
    gap: 12,
    marginTop: 6
  }
};
function ToggleRow({
  label,
  sub,
  def,
  last
}) {
  const [on, setOn] = React.useState(def);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...setStyles.toggleRow,
      borderBottom: last ? 'none' : setStyles.toggleRow.borderBottom
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: setStyles.toggleLabel
  }, label), /*#__PURE__*/React.createElement("div", {
    style: setStyles.toggleSub
  }, sub)), /*#__PURE__*/React.createElement(ST_Switch, {
    checked: on,
    onChange: setOn
  }));
}
function SettingsScreen() {
  const S = setStyles;
  return /*#__PURE__*/React.createElement("div", {
    style: S.shell
  }, /*#__PURE__*/React.createElement(ST_Header, {
    domain: "System",
    title: "Settings",
    subtitle: "CONFIG_SHELL"
  }), /*#__PURE__*/React.createElement("div", {
    style: S.content
  }, /*#__PURE__*/React.createElement("div", {
    style: S.panel
  }, /*#__PURE__*/React.createElement("div", {
    style: S.kicker
  }, "SYNC"), /*#__PURE__*/React.createElement("div", {
    style: S.title
  }, "Connection"), /*#__PURE__*/React.createElement("p", {
    style: S.text
  }, "Connect to your sync server on the PC to fetch the markdown files."), /*#__PURE__*/React.createElement(ST_Input, {
    label: "Sync host",
    defaultValue: "127.0.0.1:3001",
    helper: "Strip protocol & trailing slashes."
  }), /*#__PURE__*/React.createElement("div", {
    style: S.connRow
  }, /*#__PURE__*/React.createElement("span", {
    style: S.connDot
  }), /*#__PURE__*/React.createElement("span", {
    style: S.connText
  }, "Connected \xB7 SSOT OK")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement(ST_Button, {
    variant: "primary",
    hud: true,
    size: "sm"
  }, "Sync now"), /*#__PURE__*/React.createElement(ST_Button, {
    variant: "secondary",
    size: "sm"
  }, "Test host"))), /*#__PURE__*/React.createElement("div", {
    style: S.panel
  }, /*#__PURE__*/React.createElement("div", {
    style: S.kicker
  }, "WORKSPACE"), /*#__PURE__*/React.createElement("div", {
    style: S.title
  }, "Preferences"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(ToggleRow, {
    label: "Auto-sync on launch",
    sub: "Pull latest records when the app opens.",
    def: true
  }), /*#__PURE__*/React.createElement(ToggleRow, {
    label: "Show worker fleet",
    sub: "Surface active agents on Home.",
    def: false
  }), /*#__PURE__*/React.createElement(ToggleRow, {
    label: "Reduced motion",
    sub: "Disable ambient pulse and transitions.",
    def: true,
    last: true
  }))), /*#__PURE__*/React.createElement("div", {
    style: S.panel
  }, /*#__PURE__*/React.createElement("div", {
    style: S.kicker
  }, "BRAIN_DATABASE"), /*#__PURE__*/React.createElement("div", {
    style: S.title
  }, "Database dashboard"), /*#__PURE__*/React.createElement("div", {
    style: S.dbGrid
  }, /*#__PURE__*/React.createElement(ST_Metric, {
    value: "1,127",
    label: "Records"
  }), /*#__PURE__*/React.createElement(ST_Metric, {
    value: "4",
    label: "Workers",
    tone: "var(--clay)"
  }), /*#__PURE__*/React.createElement(ST_Metric, {
    value: "8",
    label: "Domains"
  }))), /*#__PURE__*/React.createElement("div", {
    style: S.panel
  }, /*#__PURE__*/React.createElement("div", {
    style: S.kicker
  }, "DANGER"), /*#__PURE__*/React.createElement("div", {
    style: S.title
  }, "Storage"), /*#__PURE__*/React.createElement("p", {
    style: S.text
  }, "Clears all local records and cached sync state. This cannot be undone."), /*#__PURE__*/React.createElement(ST_Button, {
    variant: "danger",
    hud: true
  }, "Wipe all storage"))));
}
window.SettingsScreen = SettingsScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/starq-nexus-mobile/SettingsScreen.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.HudLabel = __ds_scope.HudLabel;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.MetricStat = __ds_scope.MetricStat;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.NexusHeader = __ds_scope.NexusHeader;

__ds_ns.TabBar = __ds_scope.TabBar;

__ds_ns.RzBadge = __ds_scope.RzBadge;

__ds_ns.RzButton = __ds_scope.RzButton;

__ds_ns.RzNeonMark = __ds_scope.RzNeonMark;

__ds_ns.RzPanel = __ds_scope.RzPanel;

__ds_ns.RzPanelRow = __ds_scope.RzPanelRow;

__ds_ns.RzProgress = __ds_scope.RzProgress;

__ds_ns.RzStat = __ds_scope.RzStat;

__ds_ns.RzCell = __ds_scope.RzCell;

__ds_ns.RzTabBar = __ds_scope.RzTabBar;

})();
