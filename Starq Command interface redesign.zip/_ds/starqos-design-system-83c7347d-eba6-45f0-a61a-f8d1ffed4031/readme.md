# starqOS — Design System

> The visual language of **starqOS**: a calm, premium "second-brain" workspace.
> A warm charcoal shell, paper & vellum content surfaces, one rich clay accent,
> crisp structure with small radii, and a single clean sans everywhere. It should
> feel like a serious reader, a notes studio and a project operating room — **not**
> a neon control panel.

---

## 1 · Product context

**starqOS** is a personal operating system / "second brain" — a local-first
workspace on the owner's PC that indexes everything (projects, knowledge,
academia, life, organizations) into a searchable graph and dispatches a fleet of
named AI **workers** against tasks, coordinated by the human operator.

**STARQ NEXUS** is the *mobile* surface of that system — a remote companion that
mirrors data synced from the local machine and lets the operator capture,
inspect and steer from anywhere. This design system describes the **modern UI/UX
direction** the product has pivoted to (`starqOS`): away from the earlier
deep-space neon HUD, toward a warm, calm, premium reading-and-working
environment.

The mobile app's tabs, each a self-contained subapp:

| Tab | Purpose |
|-----|---------|
| **Home** | A HUD overview — clock, today's commitments, quick capture, active projects, system status |
| **Notes** | Quick-capture notes with `[[wiki-links]]`, categories and attention flags |
| **Calendar** | Appointments, study sessions, deadlines and todos |
| **Files** | Synced workspace files & assets |
| **Library** | The synced knowledge vault — categories, records, a markdown reader |
| **Settings** | Workspace paths, sync host + connection, database dashboard, preferences |

Work (project Kanban boards) and Learn (academia / exam prep) are additional
surfaces reached through navigation.

### Sources used to build this system
- **Codebase (primary source of truth):** the `starqNexusMobileBeta/` Expo /
  React Native app, accessed read-only via the mounted folder.
  - `src/styles/starqOS.ts` — the canonical token module (the warm direction).
  - `src/theme.ts` — the compatibility theme bridge (colors, spacing, radius, font, motion).
  - `STARQ_OS_THEME_FOUNDATION.md` — the written design foundation & migration plan.
  - `src/components/` — `NexusHeader`, `TabBar`, `Ticker`, plus the shared DS
    primitives in `src/components/ds/index.tsx` (Button, Badge, Card, MetricStat,
    ProgressBar, HudLabel, DocumentView).
  - `src/screens/` — `HomeScreen`, `LibraryScreen`, `ProjectsScreen`, `NotesScreen`,
    `SettingsScreen`, `CalendarScreen`, … (every color & layout pattern is lifted
    from these).
  - `src/config/projectRegistry.ts` — the real project list and domain colors.
- **Legacy design-system folder:** `starqNexusMobileBeta/STARQ NEXUS Design System/`
  documents the *previous* neon/deep-space incarnation. It is **superseded** by
  this system — kept only as a reference for what the product moved away from.

> ⚠️ **Font note:** the native app renders Space Grotesk via `@expo-google-fonts`.
> This web system loads the identical family (400/500/600/700) from the Google
> Fonts CDN (`tokens/fonts.css`). If you want a fully offline bundle, drop
> self-hosted `.woff2` files in and add `@font-face` rules. **No substitute font
> was used — this is the real product family.**

---

## 2 · Content fundamentals — how starqOS writes

The product speaks in **two registers**.

**The system register (HUD)** — terse, uppercased, tracked. Reads like a console
readout. Same family as everything else (no separate mono), distinguished by
`UPPERCASE` + wide letter-spacing.
- Section headers are **bracketed**: `[ TODAY'S COMMITMENTS ]` · `[ ACTIVE PROJECTS ]`
  · `[ SYSTEM HUD ]` · `[ QUICK CAPTURE ]`.
- Telemetry is short and absolute: `SYS_ON` · `SSOT OK` · `SYNC COMPLETE` ·
  `CONNECTED` / `DISCONNECTED` · `DONE` / `BLOCKED`.
- Status tags are `snake_case` machine tags: `SYS_ON`, `VAULT_RECORDS`,
  `CONFIG_SHELL`.
- Separators: `·` (middot), `//`, `|`. Domains/projects shown in `[BRACKETS]`.
- Small inline data uses the same voice: `HOADHA · 62% · SPRINT 5 · 31/50 TASKS`.

**The human register (prose)** — plain, direct, sentence-case, second-person.
- "Select a project domain to inspect or update active tasks."
- "Connect to your sync server on the PC to fetch the markdown files."
- "Review the sprint deliverables for the Projects board."

**Tone & rules**
- **Voice:** an operator talking to their own system. Confident, technical,
  unfussy. No marketing gloss, no exclamation hype.
- **Casing:** `UPPERCASE` (tracked) for HUD labels & telemetry; Sentence case for
  content & prose; `snake_case` for system status tags. Brand wordmark is
  lowercase `starqOS`; the nexus mark is `STARQ · NEXUS` (uppercase).
- **Person:** imperative or second-person for actions ("Sync Local Capture",
  "Customize Root Directory"). The system refers to itself by name (NEXUS,
  ATHENA), never "I".
- **Numbers carry weight:** counts, percentages and clocks (`62%`, `1,127`,
  `09:24:51`) are first-class — but only **real, synced figures**. Never invent
  filler stats.
- **Emoji:** essentially none in the modern UI. The product uses typographic
  marks (`·` `//` `»` `›` `■`) and small colored pips/squares as iconography, not
  emoji. (See §4.)
- **Vibe:** *calm, synced, under control.* Live, but composed — never frantic.

---

## 3 · Visual foundations

### Color & mood
A **warm, earthy, premium** palette built from two neutral ramps that meet at a
single accent.
- **The shell** is warm near-black: `--charcoal #171513` for the app frame,
  bottom nav and HUD screens, with `--charcoal-2 #1c1917` insets,
  `--charcoal-soft #24201d` dark panels, and warm-brown hairlines
  (`--charcoal-line #4a3b32`, `--charcoal-divider #2d2724`).
- **The content** is warm paper: `--paper #f6efe4` cards, `--paper-soft #fbf7ef`
  raised surfaces (buttons, fields, modals), `--vellum #eee1cf` sunken fills &
  separators, `--line #dccbb7` hairline borders.
- **Text** is `--ink #211c18` (primary on paper), `--muted #776b61` (secondary on
  paper), `--paper-soft` (primary on charcoal), `--muted-dark #a89989` (secondary
  on charcoal).
- **One accent: clay** `--clay #b86b43`, with `--clay-dark #7f4128` for accent
  text on light (passes AA). Tints at 8 / 12 / 18 / 24 / 40 % build fills & borders.
- **Status is restrained:** `--danger #b95045`, `--warning #a06a32`,
  `--success #617a50` — muted, never candy-bright.
- **Domain accents** are warm earth tones (`--domain-workers #8a5f48`,
  `--domain-knowledge #9b7047`, `--domain-orgs #965d52`, …) used *only* as small
  indicators (a 4px stripe, a `■` glyph) that tag a project or knowledge domain.
  > The legacy app still tags some project rows with cool cyan/emerald/blue
  > squares; the modern direction migrates these to the warm domain set above.

Mood: warm, quiet, nocturnal-but-cosy. The product **is** its UI — there is
essentially no photography.

### Type
**One family — Space Grotesk** (400/500/600/700) — everywhere. Geometric,
engineered, slightly mechanical, which lets it carry both the HUD voice and
reading copy. No mono. No cursive logo. **No negative letter-spacing.** No
viewport-scaled font sizing. Hierarchy comes from **weight and size**, not from a
second family. HUD labels are the only tracked text (`0.12em`, uppercase).
Scale: `8 / 11 / 13 / 15 / 18 / 22 / 28 / 32 / 40 / 48`. Big numerals (clock,
metrics) are weight 700 with tabular figures.

### Backgrounds & texture
Flat warm fills only. **No photography, no decorative gradients, no glass/blur, no
texture.** Depth is created by stacking the two ramps (paper card on charcoal
shell) and by hairline borders — not by imagery.

### Animation — *living, not flashy*
Composed and functional.
- **Ambient:** a single status dot pulses gently (`~2.2s` ease-in-out); the live
  clock and record counts tick on a 1–5s cadence. That's the extent of "always-on
  life" — no orbiting constellations, no radar sweeps.
- **Transitions:** quick and functional — `140ms` press, `240ms` state change, on
  `cubic-bezier(0.4, 0, 0.2, 1)`. No bounces, no springy overshoot.
- All decorative motion is gated behind `prefers-reduced-motion`.

### Interaction states
- **Hover (web):** surfaces shift one warm step (paper → paper-soft on dark,
  card → vellum hover); accent buttons darken slightly toward `--clay-dark`.
- **Press:** subtle — `activeOpacity ~0.8` in the app; on web, a small
  `transform: scale(0.98)` or opacity dip. Tactile, immediate, no big motion.
- **Focus:** inputs raise their border to `--clay` and gain the soft
  `--focus-ring` (`0 0 0 3px clay-24`). No neon glow.
- **Active nav:** the tab label goes from `--muted-dark` to `--paper-soft` +
  bold, with a short `--clay` indicator bar at the top of the tab.

### Borders, radii & elevation
- **Borders:** 1px hairlines everywhere — `--line` on paper, `--charcoal-line` on
  dark. Cards may carry a left/edge **accent stripe** in a status or domain hue.
- **Radii small & crisp:** `4` inputs/chips · `6` panels/cards · `8` modal-like
  repeated cards · `12` sheets · pill for badges & dots. **Never fully-rounded
  cards.**
- **Elevation is a soft warm shadow, never a glow.** `--shadow-card` for resting
  cards, `--shadow-raised` for menus/popovers, `--shadow-modal` for dialogs. On
  the charcoal shell, depth reads as a hairline + faint dark cast rather than a
  shadow.

### Transparency
Accent fills use clay at low alpha (`8–18%` fill, `24–40%` border). No backdrop
blur, no frosted glass — the aesthetic is clean warm fills and hairlines.

### Layout rules
Mobile-first, single column, `16px` gutters. The header is fixed chrome at the
top; the text-only **TabBar** is fixed at the bottom — every primary screen needs
`~108px` bottom padding to clear it. Content scrolls between. Project Kanban
scrolls horizontally across columns and vertically within each column. Long text
wraps inside cards; never rely on large viewport headlines on mobile.

---

## 4 · Iconography

The modern starqOS UI is **near-iconless by design** — it leans on typography and
small geometric marks instead of an icon font.
- **Tabs** are **text-only** (Home · Notes · Calendar · Files · Library ·
  Settings) — no icons, no emoji. This is a deliberate, load-bearing rule.
- **Status & data marks** are typographic / geometric: a small round **pip** (6px,
  status-colored) for live/online; a filled **■ square** (domain-colored) for
  project indicators; `»` and `›` as list bullets; `·` `//` `|` as separators;
  `→` on call-to-action buttons; a 3-line **hamburger** drawn as three bars.
- **No emoji** in the modern direction (the legacy neon system used emoji tabs &
  domain icons — explicitly dropped here).
- **The logo** is a crafted mark, not a glyph: the **apex "Λ"** — an upward peak
  suggesting ascent and a radar/antenna apex. Master art is in
  `assets/logo/starq-nexus-mark.png`; original app icons in `assets/source-icons/`.

  > ⚠️ **Asset mismatch:** the shipped logo & app-icon art are still the **legacy
  > blue** apex (from the neon era). They have *not* yet been recoloured to the
  > warm clay palette. Treat the **shape** as canonical and the **colour** as
  > pending — a clay/charcoal version of the mark is recommended. Flagged for the
  > owner.

**Guidance for new work:** keep tabs and primary navigation text-only. If you
genuinely need stroke icons (e.g. a richer web toolbar), substitute a thin-line
CDN set — **Lucide** at ~1.5px weight in `--muted` / `--clay` is the closest
match — and **flag the substitution**. The native product ships no icon font.

---

## 5 · Index / manifest

**Foundations & tokens**
- `styles.css` — the single entry point consumers link (a manifest of `@import`s).
- `tokens/colors.css` · `typography.css` · `spacing.css` · `fonts.css` · `base.css`.

**Specimen cards** (`guidelines/`, shown in the Design System tab)
- Colors: clay · charcoal · paper · status · domains · text-on-surfaces
- Type: family · scale · weights · HUD labels · numerals
- Spacing: scale · radii · elevation
- Brand: logo & wordmark · voice & copy

**Components** (`components/`, compiled into the runtime bundle)
- `core/` — **Button**, **Badge**, **HudLabel**
- `forms/` — **Input**, **Switch**
- `data/` — **Card**, **MetricStat**, **ProgressBar**
- `navigation/` — **TabBar**, **NexusHeader**
- Each ships `.jsx` + `.d.ts` + `.prompt.md`; one `*.card.html` per group.

**UI kit** (`ui_kits/starq-nexus-mobile/`)
- `index.html` — the full interactive phone prototype (start here).
- Screen components for Home, Library, Projects, Settings. See its own `README.md`.

**Assets** (`assets/`)
- `logo/starq-nexus-mark.png` — the apex logomark.
- `source-icons/` — original app icon, splash, favicon, adaptive foreground.

**Reimagined direction** (see §6)
- `tokens/reimagined.css` — the three-theme token layer (Aqua · Ember · Plasma).
- `components/reimagined/` — themed `--rz-` React primitives: **RzNeonMark**,
  **RzPanel**/**RzPanelRow**, **RzButton**, **RzBadge**, **RzStat**/**RzCell**,
  **RzProgress**, **RzTabBar** (each `.jsx` + `.d.ts` + `.prompt.md`).
- `guidelines/reimagined-themes.card.html` · `reimagined-neon-logo.card.html` ·
  `components/reimagined/reimagined.card.html`.
- `ui_kits/reimagined-command-center/index.html` — themed interactive prototype.
- `Reimagined Command Center.html` (root) — the side-by-side concept comparison.
- `starqOS Neon Logo.html` (root) — the finalized neon logo (apex tile + wordmark).
- `design_handoff_reimagined_command_center/` — Claude Code handoff package
  (spec, prototypes, token CSS, reference component source, screenshots).

**Other**
- `SKILL.md` — makes this folder usable as a downloadable Agent Skill.
- `readme.md` — this file.

---

## 6 · Reimagined direction — "Command Center" (in progress)

A **total reimagination** commissioned alongside the faithful system above:
the warm, calm starqOS recast as a **cool, dark, futuristic command center**.
It is **multi-theme** — one structural language with three switchable themes,
scoped under `[data-rz-theme]` (variables prefixed `--rz-`) so it lives beside
the warm `:root` tokens without clobbering them.

| Theme | Mood | Accent | Display / data type | Signature |
|-------|------|--------|---------------------|-----------|
| **Aqua HUD** | tactical mission-control | `#3ee0cf` | Chakra Petch / JetBrains Mono | obsidian glass, faint grid, corner ticks |
| **Ember Signal** | high-alert, decisive | `#ff7a45` | Saira / Space Mono | blue-black ink, hard edge-bars |
| **Plasma Core** | calm, powerful AI core | `#8b7bff` | Sora / JetBrains Mono | slate-violet depth, luminous glow |

**Logo:** the reimagined mark is a **1950s neon-tube cursive** wordmark
(*Yellowtail*) locked up with the heritage **apex Λ** reborn as a glowing neon
tube inside a rounded sign-tile. Bright near-white core, deep colored bloom, a
faint flicker — and it **re-tints to the active theme**. Icon / horizontal /
stacked / wordmark-only lockups plus mono-on-dark and solid-ink-on-light
fallbacks and an art-deco (*Monoton*) bonus are in `starqOS Neon Logo.html`.

**Components:** the `--rz-` React primitives in `components/reimagined/` are
theme-adopting — they read the `--rz-*` variables, so a component built once
renders correctly in any theme; switching is a single `[data-rz-theme]` flip.

**Apply a theme:**
```html
<div data-rz-theme="plasma"> … uses --rz-accent, --rz-bg, --rz-panel … </div>
```
All three themes share the same `--rz-*` semantic variables (bg / panel / line /
accent / text / muted / display / mono / radius / glow), so a component written
once works in every theme — switching is a single attribute flip.

**Status:** the token layer, the themed UI kit (Home · Work · Library · Settings
with a live theme switcher), the concept-comparison canvas and the neon-logo
exploration are built. Still open before this becomes a full peer of the warm
system: formal React components in the `--rz-` language, a recoloured/neon app
icon, and a dedicated readme + SKILL entry. **Pending the owner's sign-off on
keeping all three themes vs. promoting one.**
